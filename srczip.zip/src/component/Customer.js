import React from 'react';


function Customer(){
  
return(
    
  <div classname='Customer'>
     
    <head>
   
    </head>
   <body>
   
   <form>
     <div class="box1">
        <h2 class="lgn">Customer Profile</h2>
        <label class="uid">CustomerID </label>
        <input type="text" placeholder="Enter your UserID"/>
        <br></br>
        <br></br>
        <label class="up">NAME </label>
        <input type="text" placeholder="Enter your name"/>
        <br></br>
        <br></br>
        <label class="up1">AGE </label>
        <input type="number" placeholder="Enter your age"/>
        <br></br>
        <br></br>
        <label class="up2">ADDRESS </label>
        <input type="text" placeholder="Enter your address"/>
        <br></br>
        <br></br>
        <div class="btn1">
        <input class="btn" type="button"  value="submit" onclick="changeType"/>
        </div>
        </div>
   </form>
   </body>
   </div> 
   
       
);   
}

export default Customer;