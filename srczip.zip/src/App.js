import React from 'react';
import './App.css';
import Customer from './component/Customer';

function App() {
  return (
    <div className="App">
     

      <Customer/>
    </div>
    
  );
}

export default App;
